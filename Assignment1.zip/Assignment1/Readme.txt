
1. Both code and report are in the Ipython notebook ‘HW1_Report_Ziyang_Zhang.ipynb’.

2. Please upload the data into colab

3. Please install Numpy and Matplotlib packages.
